<div class="step">
    <h2>In welcher <span>Etage</span> befindet sich die Wohnung?</h2>
    <section>
        <select name="etage" required="required">
            <option value="Souterrain/Untergeschoss">Souterrain/Untergeschoss</option>
            <option value="Erdgeschoss">Erdgeschoss</option>
            <option value="1. Stockwerk">1. Stockwerk</option>
            <option value="2. Stockwerk">2. Stockwerk</option>
            <option value="3. Stockwerk">3. Stockwerk</option>
            <option value="4. Stockwerk">4. Stockwerk</option>
            <option value="5. Stockwerk">5. Stockwerk</option>
            <option value="6. Stockwerk oder höher">6. Stockwerk oder höher</option>
        </select>
    </section>
    <button type="button" class="button next">Weiter</button>
    <button type="button" class="button prev">Zurück</button>
</div>