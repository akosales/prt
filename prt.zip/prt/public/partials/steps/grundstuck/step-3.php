<div class="step">
    <h2>Wie sind die Bebauungsmöglichkeiten?</h2>
    <section>
        <ul class="selectable-button data" data-key="bebauung" data-has-input="false">
            <li data-value="Kurzfristik bebaubar">Kurzfristik bebaubar</li>
            <li data-value="Eingeschränkt bebaubar">Eingeschränkt bebaubar</li>
            <li data-value="Nicht behaubar">Nicht bebaubar</li>
            <li data-value="Weiß nicht">Weiß nicht</li>
        </ul>
    </section>
    <button type="button" class="button next">Weiter</button>
    <button type="button" class="button prev">Zurück</button>
</div>