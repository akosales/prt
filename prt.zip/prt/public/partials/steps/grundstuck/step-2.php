<div class="step">
    <h2>Ist das Grundstück erschlossen?</h2>
    <section>
        <ul class="selectable-button data" data-key="erschlossen" data-has-input="false">
            <li data-value="Erschlossen">Erschlossen</li>
            <li data-value="Teilerschlossen">Teilerschlossen</li>
            <li data-value="Unerschlossen">Unerschlossen</li>
        </ul>
    </section>
    <button type="button" class="button next">Weiter</button>
    <button type="button" class="button prev">Zurück</button>
</div>