<div class="step">
    <h2>Wie ist der Grundstückszuschnitt?</h2>
    <section>
        <ul class="selectable-button data" data-key="zuschnitt" data-has-input="false">
            <li data-value="Eckgrundstück">Eckgrundstück</li>
            <li data-value="Rechteckiger Zuschnitt">Rechteckiger Zuschnitt</li>
            <li data-value="Sonstiges">Sonstiges</li>
        </ul>
    </section>
    <button type="button" class="button next">Weiter</button>
    <button type="button" class="button prev">Zurück</button>
</div>